<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/icon.png')); ?>">
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <meta name="author" content="InsonCJ">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image'); ?>">
    <meta name="keywords" content="Jurnal, inson, kapitali, inson kapitali, ilmiy jurnal, iqtisodiy jurnal, ijtimoiy rivojlanish, ilmiy maqola, maqola, maqola yuborish, <?php echo $__env->yieldContent('keywords'); ?>" />
    <!-- Bootstrap CSS -->
    <!-- Jquery Js -->
    <script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>

    <link href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
    <!-- Custom Css -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <!-- slick Slider -->
    <link href="<?php echo e(asset('assets/vendor/slick/slick/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendor/slick/slick/slick-theme.css')); ?>" rel="stylesheet">
    <!-- Icofont -->
    <link href="<?php echo e(asset('assets/vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/toastr/toastr.min.css')); ?>">
    <script src="<?php echo e(asset('adassets/plugins/toastr/toastr.min.js')); ?>"></script>


    <?php echo $__env->yieldPushContent('page_css'); ?>

    <?php if($errors->any()): ?>
        <script>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error('<?php echo e($error); ?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </script>
    <?php endif; ?>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<!-- navbar -->

<?php echo $__env->make('web.web_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('body'); ?>

<!-- Footer -->
<?php echo $__env->make('web.web_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

<!-- Bootstrap Bundle Js -->
<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Slick Js -->
<script src="<?php echo e(asset('assets/vendor/slick/slick/slick.min.js')); ?>"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php if(Session::has('success_msg')): ?>
    <script>toastr.success("<?php echo e(session('success_msg')); ?>")</script>
<?php endif; ?>
<?php if(Session::has('error_msg')): ?>
    <script>toastr.error("<?php echo e(session('error_msg')); ?>")</script>
<?php endif; ?>

<script>
    window.replainSettings = { id: '91cd1b36-9657-4834-934b-62b3d97bcacc' };
    (function(u){var s=document.createElement('script');s.async=true;s.src=u;
        var x=document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);
    })('https://widget.replain.cc/dist/client.js');
</script>

<?php echo $__env->yieldPushContent('page_js'); ?>

</html>
<?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/base/web.blade.php ENDPATH**/ ?>