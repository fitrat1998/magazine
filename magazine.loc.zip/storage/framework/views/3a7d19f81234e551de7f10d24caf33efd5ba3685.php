<?php $__env->startSection('title'); ?>
    <?php if(!is_null($this_year)): ?>
        <?php echo e($this_year); ?> - yil.
    <?php endif; ?>
    Jurnal sonlari
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_name'); ?>
    <?php if(!is_null($this_year)): ?>
        <?php echo e($this_year); ?> - yil.
    <?php endif; ?>
    Jurnal sonlari
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

    <!-- Default box -->
    <div class="card card-solid ">

        <div class="card-header text-right">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-addIssue">
                + Jurnal sonlarini qo'shish
            </button>
        </div>

        <div class="card-body pb-0 table-responsive">
            <table class="table table-bordered table-striped mb-5 text-nowrap">
                <thead>
                <tr style="border: 1px solid #333;">
                    <th style="width: 10px">#</th>
                    <th>Jurnal rasmi</th>
                    <th>Jurnal soni</th>
                    <th>Jurnal Yili</th>
                    <th>Yuklash</th>
                    <th>Kelib tushgan maqolalar</th>
                    <th>Jurnal arxivi</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><img src="<?php echo e(asset('images/journals/' . $issue->image)); ?>" alt="" width="120px"></td>
                        <td><?php echo e($issue->number); ?> - son</td>
                        <td><?php echo e($issue->yil); ?> - yil</td>
                        <td> <a href="<?php echo e(route('files.journal',$issue->file)); ?>" class="btn btn-primary"><i class="fa fa-download"></i> <?php echo e($issue->file); ?></a> </td>
                        <td><a href="<?php echo e(route('admin.articles')); ?>?issue=<?php echo e($issue->id); ?>" class="btn btn-success"><i class="fa fa-eye"></i></a></td>
                        <td>
                            <a href="<?php echo e(route('admin.dois')); ?>?issue=<?php echo e($issue->id); ?>" class="btn btn-success"><i class="fa fa-archive"></i></a>
                            |
                            <a href="<?php echo e(route('admin.dois.create')); ?>?issue=<?php echo e($issue->id); ?>" class="btn btn-primary"><i class="fa fa-plus"></i></a>

                        </td>
                        <td style="width: 20%">
                            <form action="<?php echo e(route('admin.issues.destroy', $issue->id)); ?>" method="POST" onsubmit="return confirm('Jurnal sonini o\'chirmoqchimisiz?')" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    <?php echo $__env->make('admin.modal.issue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/admin/issues.blade.php ENDPATH**/ ?>