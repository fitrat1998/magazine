<?php $__env->startSection('title', __('about.journal_archive')); ?>
<?php $__env->startSection('description',  __('home.journal_name')); ?>
<?php $__env->startSection('og_image', ''); ?>

<?php $__env->startSection('body'); ?>
    <!-- Content -->
    <div class="py-3">
        <div class="container">
            <nav>
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('index')); ?>" class="text-success">
                            <i class="bi bi-house"></i> <?php echo e(__('home.home')); ?>

                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('about.journal_archive')); ?></li>
                </ol>
            </nav>
        </div>
    </div>
    <hr class="m-0">


    <!-- Team members section-->
    <section class="py-5 bg-white">
        <div class="container my-5">
            <div class="text-center">
                <h2 class="fw-bold text-body"><?php echo e(__('about.journal_archive')); ?></h2>
                <br><br>
            </div>
            <div class="row gx-5 row-cols-1">
                <div class="m-0">
                    <div class="accordion accordion-flush bg-primary rounded-3 shadow overflow-hidden" id="accordionFlushExample">
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item bg-light">
                                <h2 class="accordion-header" id="flush-heading<?php echo e($y->year); ?>">
                                    <button class="accordion-button collapsed fs-48 fw-bold" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#flush-collapse<?php echo e($y->year); ?>" aria-expanded="false" aria-controls="flush-collapseOne">
                                        <?php echo e($y->year); ?> - yil
                                    </button>
                                </h2>
                                <div id="flush-collapse<?php echo e($y->year); ?>" class="accordion-collapse collapse text-muted"
                                     aria-labelledby="flush-heading<?php echo e($y->year); ?>" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body">

                                        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 row-cols-xl-4 g-4">
                                            <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($journal->year != $y->year): ?>
                                                    <?php continue; ?>
                                                <?php endif; ?>
                                                <!-- <?php echo e($loop->index); ?> mage -->
                                                <div class="col">
                                                    <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden video-card-item shadow">
                                                        <a href="<?php echo e(route('archive.dois', $journal->id)); ?>">
                                                            <img src="<?php echo e(asset('images/journals/' . $journal->image)); ?>" class="card-img-top d-none d-lg-block" alt="...">
                                                        </a>
                                                        <div class="card-body row">
                                                            <div class="col-7">
                                                                <a href="<?php echo e(route('archive.dois', $journal->id)); ?>" class="btn-link">
                                                                    <h5 class="card-title mb-1 h6 text-dark"><?php echo e($journal['year']); ?> <?php echo e(__('home.year')); ?>. <?php echo e($journal['number']); ?> <?php echo e(__('home.number')); ?></h5>
                                                                    <p class="card-text text-muted"><?php echo e($journal['year']); ?> <?php echo e(__('home.year')); ?>.</p>
                                                                </a>
                                                            </div>
                                                            <div class="col-5 text-right">
                                                                <a href="<?php echo e(route('files.journal', $journal->file)); ?>" type="button" class="btn btn-primary btn-sm px-2 py-0">
                                                                    <i class="bi bi-download"></i> <?php echo e(__('home.download')); ?>

                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\magazine.loc\resources\views/web/archive.blade.php ENDPATH**/ ?>