<?php $__env->startSection('title', "Arxiv maqolani qo'shish"); ?>

<?php $__env->startSection('content_name', "Arxivga maqolani qo'shish"); ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/summernote/summernote-bs4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-9">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Maqolani arxivga biriktirish</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form method="POST" id="doi_form" action="<?php echo e(route('admin.dois.create')); ?>" class="card-body row" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group col-md-12">
                                <label for="title">Jurnal soni</label>
                                <select class="custom-select" id="issue_id" name="issue_id">
                                    <option disabled selected> -- Tanlang -- </option>
                                    <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($issue->id); ?>"> <?php echo e($issue->yil); ?> - yil. <?php echo e($issue->number); ?> - son</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="title">Maqola mavzusi</label>
                                <input type="text" name="title"  class="form-control" id="title" required placeholder="Maqola mavzusi" value="<?php echo e(old('title')); ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="authors">Mualliflar (* Mualliflarni to'liq F.I.SH larini yozing. Agar mualliflar ko'p bo'lsa ularni vergul bilan ajrating.</label>
                                <input type="text" name="authors"  class="form-control" id="authors" required value="<?php echo e(old('authors')); ?>" placeholder="Muallif1, Muallif2, ...">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="abstract">Maqola annotatsiyasi</label>
                                <textarea id="abstract" class="form-control" name="abstract" rows="4" placeholder="Annotatsiya"><?php echo e(old('abstract')); ?></textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="keywords">Kalit so'zlar (* Kalit so'zlarni vergul bilan ajratilgan holda kiriting!)</label>
                                <input type="text" name="keywords"  class="form-control" id="keywords" required value="<?php echo e(old('keywords')); ?>" placeholder="Kalit so'zlar">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="authors">DOI manzilini kiriting.</label>
                                <input type="text" name="doi_url"  class="form-control" id="doi_url" value="<?php echo e(old('doi_url')); ?>" placeholder="Bo'sh qolsin" disabled>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="file">Fayl yuklash(* Maqola .pdf shaklda.) </label>
                                <input type="file" name="doi_file"  class="form-control" id="doi_file" required  placeholder="file" accept=".pdf">
                            </div>

                            <hr>

                        </form>

                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary pl-5 pr-5" form="doi_form">Saqlash</button>
                        </div>
                    </div>
                    <!-- /.card -->

                </div>
                <!--/.col (left) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_js'); ?>
    <script src="<?php echo e(asset('adassets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>

    <script type="text/javascript">

        function articles_change(issue_id) {
            // var s_html="<option disabled selected> -- Tanlang -- </option>";
            

            // articles.forEach(function (article){
            //     if(Number(article['issue_id']) === Number(issue_id)){
            //         s_html += "<option value='" + article['id'] + "'>" + article['title'] + " [" +article['authors'] + "] </option>"
            //     }
            // });
            //
            // $('#article_id').html(s_html);
        }

        <?php if($issue_id>0): ?>
            $('#issue_id').val(<?php echo e($issue_id); ?>)
            
        <?php endif; ?>


        // $('#issue_id').change(function (){
        //     var issue_id = $('#issue_id').val();
        //     articles_change(issue_id);
        // })

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/admin/doi-create.blade.php ENDPATH**/ ?>