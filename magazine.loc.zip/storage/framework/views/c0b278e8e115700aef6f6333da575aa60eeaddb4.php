<div class="feature-list py-5 border-bottom bg-white">
    <div class="container py-4">
        <heading>
            <h3 class="text-center pb-4 mb-4 fw-bold text-black"><?php echo e(__('home.requirements')); ?></h3>
        </heading>
        <div class="row">
            <?php echo __('req.in'); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/web/web_requirements.blade.php ENDPATH**/ ?>