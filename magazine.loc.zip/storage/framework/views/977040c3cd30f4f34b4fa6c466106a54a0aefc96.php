<?php $__env->startSection('title', __('home.profile')); ?>
<?php $__env->startSection('description',  __('home.journal_name') ); ?>
<?php $__env->startSection('og_image', ''); ?>

<?php $__env->startSection('body'); ?>
    <!-- Content -->
    <div class="bg-primary bg-gradient">
        <!-- Login -->
        <div class="container py-5 login">
            <!-- Login -->
            <div id="login">
                <div class="m-auto bg-white shadow-sm p-5 rounded-3 text-center col-md-4 mx-auto">
                    <h3 class="fw-bold text-black mb-2"><?php echo e(__('home.profile')); ?></h3>
                    <form action="" class="text-start pt-4" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="email" class="form-label small text-muted col-12"><?php echo e(__('home.email')); ?> <small class="text-danger">*</small></label>
                            <input type="email" name="email" class="form-control h-100" id="email" placeholder="Email">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label small text-muted"><?php echo e(__('home.password')); ?> <small class="text-danger">*</small></label>
                            <input type="password" name="password" class="form-control" id="password" placeholder="********">
                        </div>

                        <button type="submit" class="btn btn-dark fw-bold fs-7 rounded-3 shadow-sm w-100 border-0 px-4 py-3 text-uppercase"><?php echo e(__('home.login')); ?></button>
                    </form>

                    <p class="text-muted mb-0"><?php echo e(__('home.ask_register')); ?> <a href="<?php echo e(route('register')); ?>" class="text-mdinfo"><?php echo e(__('home.register')); ?></a></p>
                </div>
                <p class="mb-0 text-center small text-white my-5"><?php echo e(__('home.login_problem')); ?> <a href="tel:+998932360433" class="text-decoration-underline text-white"><?php echo e(__('home.contact')); ?></a></p>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/web/login.blade.php ENDPATH**/ ?>