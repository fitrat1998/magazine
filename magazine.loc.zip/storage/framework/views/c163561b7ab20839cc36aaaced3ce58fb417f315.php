<div class="banner-search py-4">
    <div class="container">
        <div class="row flex-lg-row-reverse align-items-center">
            <div class="col-12 col-lg-6">
                <img src="<?php echo e(asset('assets/img/banner.png')); ?>" class="img-fluid" alt="#" loading="lazy">
            </div>
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold lh-1 mb-3 text-body"><?php echo e(__('home.journal_name')); ?>.</h1>
                <p class="lead fw-normal text-dark mb-0"><?php echo e(__('home.s_journal')); ?>

                </p>
                <hr>
                <div class="d-inline">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary"><?php echo e(__('home.login')); ?></a>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-primary"><?php echo e(__('home.register')); ?></a>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/web/web_banner.blade.php ENDPATH**/ ?>