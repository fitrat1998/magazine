<div class="py-5 footer btn-success">
    <div>
        <div class="container py-3">
            <div class="row">
                <div class="col-6 col-lg-2 col-md-3 ">
                    <h6 class="mb-3 text-warning fw-bold"><?php echo e(__('home.menus')); ?></h6>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('index')); ?>"><?php echo e(__('home.home')); ?></a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('about')); ?>"><?php echo e(__('home.about')); ?></a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('news')); ?>"><?php echo e(__('home.ads')); ?></a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('archive')); ?>"><?php echo e(__('home.archive')); ?></a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('experts')); ?>"><?php echo e(__('home.experts')); ?></a>
                </div>
                <div class="col-6 col-lg-2 col-md-3">
                    <h6 class="mb-3 text-warning fw-bold"><?php echo e(__('home.auth')); ?></h6>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('home.login')); ?></a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('home.register')); ?></a>
                </div>
                <div class="col-6 col-lg-2 col-md-3">
                    <h6 class="mb-3 text-warning fw-bold"><?php echo e(__('home.contact')); ?></h6>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="tel:">932360433</a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="tel:">932360433</a>
                    <a class="py-1 text-decoration-none d-block w-100 text-white" href="tel:">932360433</a>
                </div>
                <div class="col-6 col-lg-4 col-md-3 ps-lg-5">
                    <div class="col-lg-8 col-md-6">
                        <a href="<?php echo e(route('index')); ?>" class="brand d-flex align-items-center mb-3 mb-md-0 me-md-auto text-decoration-none bg-warning m-1 rounded p-3">
                        <img src="<?php echo e(asset('assets/img/'. __('home.logo'))); ?>" class="img-fluid" alt="Turkologiya">
                    </a>
                    </div>
                    <br>
                    <p><?php echo e(__('home.phone')); ?>: <a class="py-1 text-decoration-none d-inline w-100 text-white" href="tel:">932360433</a>.</p>
                    <p><?php echo e(__('home.email')); ?>: <a class="py-1 text-decoration-none d-inline w-100 text-white" href="email:">hello@lifepc.uz</a>.</p>
                    <p><?php echo e(__('home.adress')); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="py-4 bg-white footer-copyright">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <span class="me-3 small">©2023 <b class="text-success">Turkological Researchs</b> All rights reserved</span>
                <a class="text-black-50 small mx-3 text-decoration-none" href="<?php echo e(route('login')); ?>"><?php echo e(__('home.login')); ?></a>
                <a class="text-black-50 small mx-3 text-decoration-none" href="<?php echo e(route('register')); ?>"><?php echo e(__('home.register')); ?></a>
            </div>
            <div class="col-md-4 text-end">
                <a target="_blank" href="#" class="btn social-btn btn-sm text-decoration-none"><i class="icofont-facebook"></i></a>
                <a target="_blank" href="#" class="btn social-btn btn-sm text-decoration-none"><i class="icofont-telegram"></i></a>
                <a target="_blank" href="#" class="btn social-btn btn-sm text-decoration-none"><i class="icofont-linkedin"></i></a>
                <a target="_blank" href="#" class="btn social-btn btn-sm text-decoration-none"><i class="icofont-youtube-play"></i></a>
                <a target="_blank" href="#" class="btn social-btn btn-sm text-decoration-none"><i class="icofont-instagram"></i></a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\OSPanel\domains\magazine.loc\resources\views/web/web_footer.blade.php ENDPATH**/ ?>