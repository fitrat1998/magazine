<?php $__env->startSection('title', "Profilni tahrirlash"); ?>

<?php $__env->startSection('content_name', "Profilni tahrirlash"); ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/summernote/summernote-bs4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_content'); ?>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Profilni tahrirlash</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form method="POST" id="profile_update" action="<?php echo e(route('profile.settings')); ?>" class="card-body row">
                            <?php echo csrf_field(); ?>

                            <div class="form-group col-md-12">
                                <label for="email">Email:</label>
                                <input type="email"  class="form-control" id="email" required value="<?php echo e($user->email); ?>" disabled>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="fish">To'liq ismingiz:</label>
                                <input type="text" name="fish"  class="form-control" id="fish" required placeholder="F.I.SH" value="<?php echo e($user->fish); ?>">
                            </div>


                            <div class="form-group col-md-12">
                                <label for="phone">Telefon:</label>
                                <input type="tel" name="phone"  class="form-control" id="phone" value="<?php echo e($user->phone); ?>" placeholder="phone">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="workplace">Ish joyingiz:</label>
                                <input type="text" name="workplace"  class="form-control" id="workplace" value="<?php echo e($user->workplace); ?>" placeholder="Ish joyingiz">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="position">Lavozimingiz:</label>
                                <input type="text" name="position"  class="form-control" id="position" value="<?php echo e($user->position); ?>" placeholder="Lavozimingiz">
                            </div>

                            <hr>

                        </form>

                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary pl-5 pr-5" form="profile_update">Saqlash</button>
                        </div>
                    </div>
                    <!-- /.card -->

                </div>
                <!--/.col (left) -->

                <div class="col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Parolni o'zgartirish</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form method="POST" id="password_update" action="<?php echo e(route('profile.updatePassword')); ?>" class="card-body row">
                            <?php echo csrf_field(); ?>

                            <div class="form-group col-md-12">
                                <label for="authors">Eski parolingiz:</label>
                                <input type="password" name="old_password" class="form-control" id="old_password" required>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="authors">Yangi parol:</label>
                                <input type="password" name="new_password" class="form-control" id="new_password" required>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="authors">Yangi parolni takrorlash:</label>
                                <input type="password" name="new_password_confirmation" class="form-control" id="new_password_confirmation" required>
                            </div>

                            <hr>

                        </form>

                        <div class="card-footer text-right">
                            <button type="submit" class="btn btn-primary pl-5 pr-5" form="password_update">Saqlash</button>
                        </div>
                    </div>
                    <!-- /.card -->

                </div>

            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_js'); ?>
    <script src="<?php echo e(asset('adassets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>

    <script type="text/javascript">
        // $('#text_uz').summernote({
        //     height: 100,
        // });
        // $('#text_en').summernote({
        //     height: 100,
        // });
        // $('#text_ru').summernote({
        //     height: 100,
        // });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\magazine.loc\resources\views/user/profile-edit.blade.php ENDPATH**/ ?>