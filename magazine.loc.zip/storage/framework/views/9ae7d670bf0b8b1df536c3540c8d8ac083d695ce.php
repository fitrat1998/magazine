<?php $__env->startSection('title'); ?>
    Arxiv Maqolalar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_name'); ?>
    Arxiv Maqolalar

<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('adassets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_content'); ?>

    <!-- Default box -->
    <div class="card card-solid ">

        <div class="card-body pb-0 table-responsive">
            <table id="articles_table" class="table table-bordered table-striped mb-5">
                <thead>
                    <tr style="border: 1px solid #333;">
                        <th style="width: 10px">#</th>
                        <th>Maqola mavzusi</th>
                        <th>Mualliflar</th>
                        <th>Abstract</th>
                        <th>DOI_URL</th>
                        <th>FILE | Delete</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $dois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 10px"><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($doi->title); ?></td>
                        <td class="text-bold"><?php echo e($doi->authors); ?></td>
                        <td><?php echo e($doi->abstract); ?></td>
                        <td><?php echo e($doi->doi_url); ?></td>
                        <td> <a href="<?php echo e(route('dois.file',$doi->doi_file)); ?>" class="btn btn-primary"><i class="fa fa-download"></i> </a>

                            |
                            <form action="<?php echo e(route('admin.dois.destroy', $doi->id)); ?>" method="POST" onsubmit="return confirm('Arxiv maqolani o\'chirmoqchimisiz?')" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_js'); ?>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('adassets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adassets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>

    <script>
        $(function () {
            $("#articles_table").DataTable({
                "responsive": true, "lengthChange": true, "autoWidth": false,
                // "buttons": [ "print"],
            }).buttons().container().appendTo('#articles_table_wrapper .col-md-6:eq(0)');
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\magazine.loc\resources\views/admin/dois.blade.php ENDPATH**/ ?>