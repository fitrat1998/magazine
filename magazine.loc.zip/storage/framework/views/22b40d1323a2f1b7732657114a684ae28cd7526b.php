<section class="bg-light py-5 feature-list border-bottom">
    <div class="container py-4">
        <div  class="pb-2">
            <h4 class="fw-bold text-black"><?php echo e(__('home.journals')); ?> </h4>
            <p class="mb-4 text-muted"><?php echo e(__('home.journals_last4')); ?> </p>
        </div>
        <div class="row row-cols-2 row-cols-md-4 row-cols-lg-4 row-cols-xl-4 g-4">
            <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $journal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <?php echo e($loop->index); ?> mage -->
                <div class="col">
                    <div class="card h-100 border-0 shadow-sm rounded-3 overflow-hidden video-card-item">
                        <img src="<?php echo e(asset('images/journals/' . $journal->image)); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title mb-1 h6 text-dark"><?php echo e($journal['year']); ?>-yil. <?php echo e($journal['number']); ?>-son</h5>
                            <p class="card-text text-muted"><?php echo e($journal['year']); ?>-yil.</p>
                        </div>
                        <div class="card-footer bg-white border-0 d-flex align-items-center justify-content-between p-3 border-top">

                            <a href="<?php echo e(route('files.journal', $journal->file)); ?>" type="button" class="btn btn-primary btn-sm px-2 py-0">
                                <i class="bi bi-download"></i> <?php echo e(__('home.download')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    </div>
</section>
<?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/web/web_journals.blade.php ENDPATH**/ ?>