<?php $__env->startSection('title', 'Bosh sahifa'); ?>

<?php $__env->startSection('content_name', 'Bosh sahifa'); ?>

<?php $__env->startPush('page_css'); ?>
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main_content'); ?>

    <div class="row">
        <div class="col-lg-3 col-6">

            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e($users); ?></h3>
                    <p>Foydalanuvchilar</p>
                </div>
                <div class="icon">
                    <i class="ion ion-people"></i>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-6">

            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e($articles); ?></h3>
                    <p>Maqolalar</p>
                </div>
                <div class="icon">
                    <i class="ion ion-document"></i>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-6">

            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e($issues); ?></h3>
                    <p>Jurnal sonlari</p>
                </div>
                <div class="icon">
                    <i class="ion ion-list-outline"></i>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-6">

            <div class="small-box bg-danger">
                <div class="inner">
                    <h3><?php echo e($experts); ?></h3>
                    <p>Ekspertlar</p>
                </div>
                <div class="icon">
                    <i class="ion ion-person-add"></i>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\magazine.loc\resources\views/admin/home.blade.php ENDPATH**/ ?>