(function($) {
  "use strict"; // Start of use strict

  //   Start Code

})(jQuery); // End of use strict