<body>

    <h1>{{ $mailData['title'] }}</h1>

    <p>Your verify code: {{ $mailData['password'] }}</p>

    <p>Thank you</p>
</body>
</html>