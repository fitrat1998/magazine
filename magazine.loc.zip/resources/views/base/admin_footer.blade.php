<footer class="main-footer">
      <!-- Default to the left -->
      <strong>Copyright &copy; 2023 <a href="https://lifepc.uz">Esanov Otabek</a>.</strong> All rights reserved.
</footer>
