<footer class="main-footer">
      <!-- Default to the left -->
      <strong>Copyright &copy; 2023 <a href="https://">Turkologik Tadqiqotlar</a>.</strong> All rights reserved.
</footer>
