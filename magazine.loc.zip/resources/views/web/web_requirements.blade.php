<div class="feature-list py-5 border-bottom bg-white">
    <div class="container py-4">
        <heading>
            <h3 class="text-center pb-4 mb-4 fw-bold text-success">{{ __('home.requirements') }}</h3>
        </heading>
        <div class="row  text-success">
            {!!  __('req.in') !!}
        </div>
    </div>
</div>
